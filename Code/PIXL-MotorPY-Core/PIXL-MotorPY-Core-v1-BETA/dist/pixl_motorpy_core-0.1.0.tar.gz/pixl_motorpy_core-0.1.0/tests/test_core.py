import sys
from pathlib import Path

import pixl_core


CORPUS = (
    Path(__file__).parents[3]
    / "PIXL-MotorPY"
    / "PIXL-MotorPY-v1-BETA"
    / "tests"
    / "corpus"
)


def test_core_import_does_not_load_graphical_modules():
    assert "PIL" not in sys.modules
    assert "tkinter" not in sys.modules


def test_process_text_returns_normalized_ir_without_images():
    text = (CORPUS / "valid" / "basic.pixl").read_text(encoding="utf-8")
    result, diagnostics = pixl_core.process_text(text, file="basic.pixl")

    assert not diagnostics.has_errors
    assert isinstance(result, pixl_core.ProcessedDocument)
    assert result.canvas == pixl_core.Canvas(2, 1)
    assert result.layers[0].operations[0].color == pixl_core.ColorRGBA8(255, 0, 0, 255)
    assert not hasattr(result, "pixels")


def test_fill_exposes_undeclared_only_policy():
    text = """PIXL(1.1)
CANVAS(2, 1)
TIPE(bit)
HEX8()
LAYER(1)
fill(1-2, 1-1, 00FF00FF)
"""
    result, diagnostics = pixl_core.process_text(text)

    assert not diagnostics.has_errors
    operation = result.layers[0].operations[0]
    assert isinstance(operation, pixl_core.FillOperation)
    assert operation.write_policy == "UNDECLARED_ONLY"


def test_animation_preserves_frames_layers_and_durations():
    text = (CORPUS / "animation" / "basic.pixl").read_text(encoding="utf-8")
    result, diagnostics = pixl_core.process_animation(text, file="basic.pixl")

    assert not diagnostics.has_errors
    assert isinstance(result, pixl_core.ProcessedAnimation)
    assert [(frame.number, frame.duration_ms) for frame in result.frames] == [(1, 10), (2, 20)]


def test_invalid_document_does_not_produce_processed_ir():
    result, diagnostics = pixl_core.process_text("PIXL(9.9)\n", file="bad.pixl")

    assert result is None
    assert diagnostics.has_errors
